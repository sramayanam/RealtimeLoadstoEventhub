﻿using System;
using System.Diagnostics;
using Newtonsoft.Json.Linq;
using Satori.Rtm;
using Satori.Rtm.Client;
using System.Configuration;

namespace SatoriStreamingData
{
    class Program
    {
        const string endpoint = "wss://open-data.api.satori.com";
        const string channel = "wiki-rc-feed";
        static void Main()
        {
            EventHubsTraceListener evthublistener = new EventHubsTraceListener();
            string appkey = ConfigurationManager.AppSettings["Satori.Key"];

            // Log messages from SDK to the console
            Trace.Listeners.Add(new ConsoleTraceListener());

            IRtmClient client = new RtmClientBuilder(endpoint, appkey).Build();
            client.OnEnterConnected += cn => Console.WriteLine("Connected to Satori RTM!");
            client.Start();

            // Create subscription observer to observe channel subscription events 
            var observer = new SubscriptionObserver();

            observer.OnSubscriptionData += (ISubscription sub, RtmSubscriptionData data) =>
            {
                foreach (JToken msg in data.Messages)              
                {            
                    if (msg["change_size"].Type != JTokenType.Null & msg.SelectToken("geo_ip.country_name") != null)
                    {
                        Console.WriteLine("Got message outer: " + (string)msg.SelectToken("geo_ip.country_name"));
                        if (msg.Value<int>("change_size") > 20) {
                            evthublistener.Write(msg);
                            Console.WriteLine("Got message inner: " + msg);
                        }
                    } 
                 
                }
            };

            client.CreateSubscription(channel, SubscriptionModes.Simple, observer);

            Console.ReadKey();

            // Stop and clean up the client before exiting the program
            client.Dispose().Wait();
        }
    }


    
}

